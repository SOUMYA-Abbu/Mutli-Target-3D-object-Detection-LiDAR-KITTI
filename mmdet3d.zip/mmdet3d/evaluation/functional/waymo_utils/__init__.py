# Copyright (c) OpenMMLab. All rights reserved.

from .prediction_to_waymo import Prediction2Waymo

__all__ = ['Prediction2Waymo']
