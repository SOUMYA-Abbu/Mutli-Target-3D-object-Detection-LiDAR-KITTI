# Copyright (c) OpenMMLab. All rights reserved.
from .voxel_generator import VoxelGenerator

__all__ = ['VoxelGenerator']
