# Copyright (c) OpenMMLab. All rights reserved.
import torch
from mmcv.cnn import build_norm_layer
from mmcv.ops import DynamicScatter
from torch import nn
from torch import nn
from torch.nn import functional as F
from mmdet3d.registry import MODELS

import torch
import torch.nn as nn
import torch.nn.functional as F

def get_paddings_indicator(actual_num, max_num, axis=0):

    actual_num = torch.unsqueeze(actual_num, axis + 1)
    max_num_shape = [1] * len(actual_num.shape)
    max_num_shape[axis + 1] = -1
    max_num = torch.arange(
        max_num, dtype=torch.int, device=actual_num.device).view(max_num_shape)
    paddings_indicator = actual_num.int() > max_num
    return paddings_indicator

class MultiHeadSelfAttention(nn.Module):
    def __init__(self, embed_size, num_heads):
        super().__init__()
        self.embed_size = embed_size
        self.num_heads = num_heads
        self.head_dim = embed_size // num_heads

        assert self.head_dim * num_heads == embed_size, "Embed size must be divisible by num_heads"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(num_heads * self.head_dim, embed_size)

    def forward(self, values, keys, query, mask):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

        values = values.reshape(N, value_len, self.num_heads, self.head_dim)
        keys = keys.reshape(N, key_len, self.num_heads, self.head_dim)
        queries = query.reshape(N, query_len, self.num_heads, self.head_dim)

        values = self.values(values)
        keys = self.keys(keys)
        queries = self.queries(queries)

        attention = torch.einsum('nqhd,nkhd->nhqk', [queries, keys])

        if mask is not None:
            attention = attention.masked_fill(mask == 0, float('-1e20'))

        attention = F.softmax(attention / (self.embed_size ** (1 / 2)), dim=3)
        out = torch.einsum('nhql,nlhd->nqhd', [attention, values]).reshape(N, query_len, self.num_heads * self.head_dim)
        out = self.fc_out(out)

        return out

class TransformerBlock(nn.Module):
    def __init__(self, embed_size, num_heads, dropout, forward_expansion):
        super().__init__()
        self.attention = MultiHeadSelfAttention(embed_size, num_heads)
        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)
        self.feed_forward = nn.Sequential(
            nn.Linear(embed_size, forward_expansion * embed_size),
            nn.ReLU(),
            nn.Linear(forward_expansion * embed_size, embed_size),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, value, key, query, mask):
        attention = self.attention(value, key, query, mask)
        x = self.dropout(self.norm1(attention + query))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out

@MODELS.register_module()
class VoxelAttentionEncoder(nn.Module):
    def __init__(self, 
                 in_channels=4,
                 feat_channels=(64, ),
                 with_distance=False,
                 with_cluster_center=True,
                 with_voxel_center=True,
                 voxel_size=(0.2, 0.2, 4),
                 point_cloud_range=(0, -40, -3, 70.4, 40, 1),
                 norm_cfg=dict(type='BN1d', eps=1e-3, momentum=0.01),
                 mode='max',
                 legacy=True,
                 
                 embed_size=64, num_layers=2, num_heads=4,  forward_expansion=2, dropout=0.1, max_length=1000):
        super().__init__()
        self._with_distance = with_distance
        self._with_cluster_center = with_cluster_center
        self._with_voxel_center = with_voxel_center
        self.legacy = legacy
        self.vx = voxel_size[0]
        self.vy = voxel_size[1]
        self.vz = voxel_size[2]
        self.x_offset = self.vx / 2 + point_cloud_range[0]
        self.y_offset = self.vy / 2 + point_cloud_range[1]
        self.z_offset = self.vz / 2 + point_cloud_range[2]
        self.point_cloud_range = point_cloud_range

        # self.linear = nn.Linear(32 * 10, embed_size)  # Adjusted input features to 32*4
        self.linear = nn.Linear(4, embed_size) 
        self.layers = nn.ModuleList([TransformerBlock(embed_size, num_heads, dropout, forward_expansion) for _ in range(num_layers)])
        self.dropout = nn.Dropout(dropout)
        self.fc_out = nn.Linear(embed_size, 64)
        # self.positional_encoding = nn.Parameter(torch.randn(1, max_length, embed_size))

    # def forward(self, x, mask=None):
    def forward(self, features, num_points, coors, *args, **kwargs):

        # mask=None

        # features_ls = [features]

        # if self._with_cluster_center:
        #     points_mean = features[:, :, :3].sum(
        #         dim=1, keepdim=True) / num_points.type_as(features).view(
        #             -1, 1, 1)
        #     f_cluster = features[:, :, :3] - points_mean
        #     features_ls.append(f_cluster)

        # dtype = features.dtype
        # if self._with_voxel_center:
        #     if not self.legacy:
        #         f_center = torch.zeros_like(features[:, :, :3])
        #         f_center[:, :, 0] = features[:, :, 0] - (
        #             coors[:, 3].to(dtype).unsqueeze(1) * self.vx +
        #             self.x_offset)
        #         f_center[:, :, 1] = features[:, :, 1] - (
        #             coors[:, 2].to(dtype).unsqueeze(1) * self.vy +
        #             self.y_offset)
        #         f_center[:, :, 2] = features[:, :, 2] - (
        #             coors[:, 1].to(dtype).unsqueeze(1) * self.vz +
        #             self.z_offset)
        #     else:
        #         f_center = features[:, :, :3]
        #         f_center[:, :, 0] = f_center[:, :, 0] - (
        #             coors[:, 3].type_as(features).unsqueeze(1) * self.vx +
        #             self.x_offset)
        #         f_center[:, :, 1] = f_center[:, :, 1] - (
        #             coors[:, 2].type_as(features).unsqueeze(1) * self.vy +
        #             self.y_offset)
        #         f_center[:, :, 2] = f_center[:, :, 2] - (
        #             coors[:, 1].type_as(features).unsqueeze(1) * self.vz +
        #             self.z_offset)
        #     features_ls.append(f_center)

        # if self._with_distance:
        #     points_dist = torch.norm(features[:, :, :3], 2, 2, keepdim=True)
        #     features_ls.append(points_dist)

        # features = torch.cat(features_ls, dim=-1)
        # voxel_count = features.shape[1]
        # mask = get_paddings_indicator(num_points, voxel_count, axis=0)
        # mask = torch.unsqueeze(mask, -1).type_as(features)
        # features *= mask

        # x = self.linear(x.view(x.size(0), x.size(1), -1))  # Reshape to (n, 128)
        # features = self.linear(features.view(features.size(0), -1, 32 * 10))  # Correct reshaping to (n, 128)
        features = self.linear(features)
        # features = self.dropout(features + self.positional_encoding[:, :features.size(1), :])
        features = self.dropout(features )
        for layer in self.layers:
            features = layer(features, features, features, None)
        features = features.mean(dim=1)
        return self.fc_out(features).squeeze()
    



#--------------------------------------------------back1---------------------------------------

# # Copyright (c) OpenMMLab. All rights reserved.
# import torch
# from mmcv.cnn import build_norm_layer
# from mmcv.ops import DynamicScatter
# from torch import nn
# from torch import nn
# from torch.nn import functional as F
# from mmdet3d.registry import MODELS

# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# class MultiHeadSelfAttention(nn.Module):
#     def __init__(self, embed_size, num_heads):
#         super().__init__()
#         self.embed_size = embed_size
#         self.num_heads = num_heads
#         self.head_dim = embed_size // num_heads

#         assert self.head_dim * num_heads == embed_size, "Embed size must be divisible by num_heads"

#         self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
#         self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
#         self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
#         self.fc_out = nn.Linear(num_heads * self.head_dim, embed_size)

#     def forward(self, values, keys, query, mask):
#         N = query.shape[0]
#         value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]

#         values = values.reshape(N, value_len, self.num_heads, self.head_dim)
#         keys = keys.reshape(N, key_len, self.num_heads, self.head_dim)
#         queries = query.reshape(N, query_len, self.num_heads, self.head_dim)

#         values = self.values(values)
#         keys = self.keys(keys)
#         queries = self.queries(queries)

#         attention = torch.einsum('nqhd,nkhd->nhqk', [queries, keys])

#         if mask is not None:
#             attention = attention.masked_fill(mask == 0, float('-1e20'))

#         attention = F.softmax(attention / (self.embed_size ** (1 / 2)), dim=3)
#         out = torch.einsum('nhql,nlhd->nqhd', [attention, values]).reshape(N, query_len, self.num_heads * self.head_dim)
#         out = self.fc_out(out)

#         return out

# class TransformerBlock(nn.Module):
#     def __init__(self, embed_size, num_heads, dropout, forward_expansion):
#         super().__init__()
#         self.attention = MultiHeadSelfAttention(embed_size, num_heads)
#         self.norm1 = nn.LayerNorm(embed_size)
#         self.norm2 = nn.LayerNorm(embed_size)
#         self.feed_forward = nn.Sequential(
#             nn.Linear(embed_size, forward_expansion * embed_size),
#             nn.ReLU(),
#             nn.Linear(forward_expansion * embed_size, embed_size),
#         )
#         self.dropout = nn.Dropout(dropout)

#     def forward(self, value, key, query, mask):
#         attention = self.attention(value, key, query, mask)
#         x = self.dropout(self.norm1(attention + query))
#         forward = self.feed_forward(x)
#         out = self.dropout(self.norm2(forward + x))
#         return out

# @MODELS.register_module()
# class VoxelAttentionEncoder(nn.Module):
#     def __init__(self, embed_size=64, num_layers=2, num_heads=4,  forward_expansion=2, dropout=0.1, max_length=1000):
#         super().__init__()
#         self.linear = nn.Linear(32 * 4, embed_size)  # Adjusted input features to 32*4
#         self.layers = nn.ModuleList([TransformerBlock(embed_size, num_heads, dropout, forward_expansion) for _ in range(num_layers)])
#         self.dropout = nn.Dropout(dropout)
#         self.fc_out = nn.Linear(embed_size, 64)
#         # self.positional_encoding = nn.Parameter(torch.randn(1, max_length, embed_size))

#     # def forward(self, x, mask=None):
#     def forward(self, features, num_points, coors, *args, **kwargs):
#         mask=None
#         # x = self.linear(x.view(x.size(0), x.size(1), -1))  # Reshape to (n, 128)
#         features = self.linear(features.view(features.size(0), -1, 32 * 4))  # Correct reshaping to (n, 128)
#         # features = self.dropout(features + self.positional_encoding[:, :features.size(1), :])
#         features = self.dropout(features )
#         for layer in self.layers:
#             features = layer(features, features, features, mask)
#         return self.fc_out(features).squeeze()