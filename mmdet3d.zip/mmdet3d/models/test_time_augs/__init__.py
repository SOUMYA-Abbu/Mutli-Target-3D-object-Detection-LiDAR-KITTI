# Copyright (c) OpenMMLab. All rights reserved.
from .merge_augs import merge_aug_bboxes_3d

__all__ = ['merge_aug_bboxes_3d']
